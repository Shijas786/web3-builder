# Quick Start Guide

## 🚀 Get Started in 3 Steps

### 1. Install Dependencies
```bash
npm install
```

### 2. Test Locally
```bash
# Test randomness
npm test

# Generate files
npm start

# Generate mini app
npm run miniapp

# Add human tweaks
npm run human

# Test everything
npm run test:full
```

### 3. Deploy to GitHub

#### Setup Repository
```bash
# Push to GitHub
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

#### Configure Secrets
Go to repo **Settings → Secrets and variables → Actions** and add:

**Required:**
- `GITHUB_TOKEN` - Personal Access Token with `repo` scope
  - Or use default: `${{ secrets.GITHUB_TOKEN }}`

**Optional:**
- `DEPLOY_ENABLED` - Set to `true` to enable deployments
- `FORK_OWNER` - Your fork account (if using fork flow)
- `PR_DAILY_LIMIT` - Max PRs per day (default: 2)
- `ISSUE_CREATE_DAILY_LIMIT` - Max issues created per day (default: 2)
- `ISSUE_CLOSE_DAILY_LIMIT` - Max issues closed per day (default: 2)

#### Configure Variables (Optional)
Go to repo **Settings → Secrets and variables → Actions → Variables**:

- `ENABLE_FORK_FLOW` - Set to `true` to use fork-based PRs

#### Enable Actions
1. Go to **Actions** tab
2. Click "I understand my workflows, go ahead and enable them"
3. Workflow will run on schedule (twice daily) or manually

---

## 📋 Quick Commands

| Command | Description |
|---------|-------------|
| `npm start` | Generate changelog & readme |
| `npm run miniapp` | Create Base or Farcaster mini app |
| `npm run human` | Add human-like tweaks |
| `npm test` | Test randomness functions |
| `npm run test:full` | Run complete workflow |

---

## 🎯 What It Does

### Automatically:
✅ Generates Web3 mini apps (Base & Farcaster)  
✅ Makes human-like code changes  
✅ Creates PRs with random titles  
✅ Opens/closes issues with varied content  
✅ Respects daily safety caps  
✅ Uses realistic timing patterns  

### Randomly Generated:
- 18 commit message styles
- 10 PR title formats
- 10 issue title patterns
- 10 label combinations
- 45% Base dApp / 45% Farcaster / 10% Both
- Variable chances by day & time

---

## 📁 Generated Mini Apps

### Base Mini App
```bash
cd miniapps/base-{name}-{timestamp}/
npm install
npm run dev
```
Features: OnchainKit, useMiniKit hook, React + TypeScript

### Farcaster Mini App
```bash
cd miniapps/farcaster-{name}-{timestamp}/
npm install
npm run dev
```
Features: Quick Auth, @farcaster/miniapp-sdk, React + TypeScript

**Note:** Full SDK features require deployment and access from Base App or Farcaster clients.

---

## ⚙️ Workflow Schedule

- **Morning UTC**: 9:15 AM
- **Afternoon UTC**: 4:45 PM
- **Manual**: Actions → Run workflow

Each run:
1. Random delay (0-20 min)
2. Generate changes
3. Generate mini app (variable chance)
4. Human tweaks
5. Commit with random message
6. Create PR with random title
7. Maybe create issue (25%)
8. Maybe close issue (15%)

---

## 🔒 Safety Features

### Daily Caps (per actor)
- Max 2 PRs
- Max 2 issue creates
- Max 2 issue closes

### Time Awareness
- 90% activity during work hours (9-5 UTC)
- 60% activity evenings
- 10% activity nights
- 85% weekdays / 30% weekends

### Randomness
- All messages/titles varied
- No predictable patterns
- Human-like timing

---

## 🐛 Troubleshooting

### Workflow doesn't run
- Check Actions tab is enabled
- Verify secrets are set
- Check workflow file syntax

### No mini apps generated
- It's random (20-60% chance by day)
- Run `npm run miniapp` locally to test

### PRs/Issues not created
- Check daily caps (may be reached)
- Verify GitHub token permissions
- Check environment variables

### Mini app won't start
- Ensure you're in mini app directory
- Run `npm install` first
- Check Node version (>=20)

---

## 📚 Documentation

- **[README.md](README.md)** - Full project overview
- **[TESTING.md](TESTING.md)** - Complete testing guide
- **[RANDOMNESS.md](RANDOMNESS.md)** - Randomness features
- **[MINI_APPS.md](MINI_APPS.md)** - SDK integration details

---

## 🎓 Next Steps

1. ✅ Test locally with `npm run test:full`
2. ✅ Push to GitHub
3. ✅ Configure secrets
4. ✅ Enable Actions
5. ✅ Run workflow manually first
6. ✅ Monitor scheduled runs
7. ✅ Check generated PRs/issues
8. ✅ Deploy mini apps

---

## 🌟 Pro Tips

- **Test first:** Always run `npm run test:full` before deploying
- **Check caps:** Monitor daily limits to avoid rate limiting
- **Vary timing:** Workflow runs at different times look more human
- **Fork flow:** Use `ENABLE_FORK_FLOW=true` for external contributor pattern
- **Mini apps:** Deploy to test full SDK features
- **Randomness:** Run `npm test` multiple times to see variety

---

## 📞 Support

- Check [TESTING.md](TESTING.md) for detailed tests
- Review workflow logs in Actions tab
- Verify environment variables are set
- Test scripts locally before deploying

---

**Ready to go?** Run `npm run test:full` to verify everything works! 🚀
