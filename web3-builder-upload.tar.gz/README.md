# Auto Web3 Builder — Collaboration & Human-like Activity

Automated GitHub contribution system that generates Web3 mini apps, creates PRs, and manages issues with human-like patterns.

## Features

✅ **Mini App Generation** (50% chance per run)
- **Base dApps**: Smart contracts + Web3 frontend
- **Farcaster Frames**: Interactive social frames with meta tags

✅ **Human-like Activity**
- Random delays (0–15 min)
- Small README/code tweaks
- Varied commit messages
- Natural timing patterns

✅ **Fork → PR Flow** (optional)
- Push from fork to upstream
- Simulates external contributor

✅ **Daily Safety Caps**
- Max 2 PRs per day
- Max 2 issue creates per day
- Max 2 issue closes per day
- Actor-aware tracking

✅ **Scheduled Runs**
- 2x daily via GitHub Actions
- Manual workflow dispatch

## Setup

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure GitHub Secrets
Required:
- `GITHUB_TOKEN` — PAT with `repo` permissions

Optional:
- `DEPLOY_ENABLED` — flag for deployment steps
- `FORK_OWNER` — fork account (if using fork flow)

### 3. Configure Repo Variables (optional)
- `ENABLE_FORK_FLOW` — set to `true` to use fork-based PRs

### 4. Configure Daily Limits (optional)
Set environment variables:
- `PR_DAILY_LIMIT` (default: 2)
- `ISSUE_CREATE_DAILY_LIMIT` (default: 2)
- `ISSUE_CLOSE_DAILY_LIMIT` (default: 2)

## Local Testing

```bash
# Generate changes
npm start

# Generate mini app
npm run miniapp

# Human-like tweaks
npm run human
```

## Generated Mini Apps

### Base dApp Structure
```
miniapps/base-{name}-{timestamp}/
├── Contract.sol       # Solidity smart contract
├── index.html         # Web3 frontend
├── app.js            # Web3 interaction logic
└── README.md         # Deployment guide
```

### Farcaster Frame Structure
```
miniapps/farcaster-{name}-{timestamp}/
├── index.html         # Frame with meta tags
├── api.js            # Next.js API route
└── README.md         # Frame deployment guide
```

## Workflows

### `collab` Job (Default)
1. Random delay (0–15 min)
2. Run generator (changelog, readme)
3. Generate mini app (50% chance)
4. Human-like tweaks
5. Push to branch
6. Create PR (with daily cap check)
7. Maybe create/close issues

### `collab-fork` Job (Optional)
Same as above, but:
- Ensures fork exists
- Pushes to fork remote
- Opens PR from fork → upstream

## Architecture

```
generate_and_commit.mjs  → Core file changes
generate_miniapp.mjs     → Base dApp or Farcaster frame
human_edit.mjs           → Random tweaks
github.mjs               → GitHub API wrapper with caps
.github/workflows/       → Automation
```

## Safety Features

- **Rate limiting**: Daily caps per actor
- **Random timing**: Delays and 50% mini app generation
- **Varied content**: Faker-generated names and phrases
- **Gitignore**: Mini apps excluded by default (remove to commit them)

## Example Output

```bash
✅ Base dApp created: miniapps/base-ergonomic-hat-2025-10-01T09-30-00-000Z
✅ Farcaster Frame created: miniapps/farcaster-protocol-2025-10-01T09-31-15-123Z
✅ PR created: Auto PR 2025-10-01T09:32:00.000Z owner:auto-1234567890
📌 Issue created.
⏳ PR limit reached today (2/2). Skipping PR.
```

## Contributing

This project simulates contributions. To actually contribute:
1. Fork manually
2. Make real changes
3. Open a genuine PR

## License

MIT

<!-- We need to connect the open-source CLI port! -->
