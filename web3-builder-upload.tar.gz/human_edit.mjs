import fs from "fs";
import { faker } from "@faker-js/faker";
import { chance, randomInt, getRandomBuzzPhrase } from "./randomness.mjs";

// Variable chance: tweak README (40-70%)
if (chance(randomInt(40, 70))) {
  const phrases = [
    `\nNote: ${faker.hacker.phrase()}`,
    `\n> ${getRandomBuzzPhrase()}`,
    `\n## ${faker.commerce.productAdjective()} Update\n${faker.company.catchPhrase()}`,
    `\n<!-- ${faker.hacker.phrase()} -->`,
    `\n**${faker.company.buzzVerb()}** ${faker.company.buzzNoun()}`
  ];
  fs.appendFileSync("README.md", phrases[randomInt(0, phrases.length - 1)] + "\n");
  console.log("✏️  README tweaked");
}

// Variable chance: tweak frontend (20-50%)
if (chance(randomInt(20, 50)) && fs.existsSync("frontend")) {
  const files = fs.readdirSync("frontend").filter(f=>f.endsWith(".jsx"));
  if (files.length) {
    const file = "frontend/" + files[randomInt(0, files.length - 1)];
    const comments = [
      `\n// ${getRandomBuzzPhrase()}`,
      `\n// TODO: ${faker.hacker.verb()} ${faker.hacker.noun()}`,
      `\n/* ${faker.company.catchPhrase()} */`,
      `\n// FIXME: optimize ${faker.hacker.noun()}`
    ];
    fs.appendFileSync(file, comments[randomInt(0, comments.length - 1)] + "\n");
    console.log("✏️  Frontend tweaked");
  }
}

// New: occasionally create a NOTES.md file (10%)
if (chance(10) && !fs.existsSync("NOTES.md")) {
  fs.writeFileSync("NOTES.md", `# Development Notes

## ${new Date().toLocaleDateString()}

- ${faker.hacker.phrase()}
- ${getRandomBuzzPhrase()}
- Consider ${faker.hacker.verb()}ing the ${faker.hacker.noun()}

---
Auto-generated notes
`);
  console.log("📝 NOTES.md created");
}
