import { faker } from "@faker-js/faker";

/**
 * Randomness utilities for human-like behavior
 */

// Random chance with percentage
export function chance(percentage) {
  return Math.random() * 100 < percentage;
}

// Random number in range
export function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Random delay in seconds
export function randomDelay(minSec, maxSec) {
  return randomInt(minSec, maxSec);
}

// Random day of week (weighted towards weekdays)
export function shouldRunToday() {
  const day = new Date().getDay(); // 0=Sun, 6=Sat
  
  // Weekend: 30% chance
  if (day === 0 || day === 6) {
    return chance(30);
  }
  
  // Weekday: 85% chance
  return chance(85);
}

// Random hour preferences (simulate human work patterns)
export function getRandomHourWeight() {
  const hour = new Date().getUTCHours();
  
  // Night hours (0-6): 10% activity
  if (hour >= 0 && hour < 6) return 0.1;
  
  // Morning (6-9): 40% activity
  if (hour >= 6 && hour < 9) return 0.4;
  
  // Peak work (9-17): 90% activity
  if (hour >= 9 && hour < 17) return 0.9;
  
  // Evening (17-22): 60% activity
  if (hour >= 17 && hour < 22) return 0.6;
  
  // Late night (22-24): 20% activity
  return 0.2;
}

// Should skip this run based on time-of-day?
export function shouldSkipByTimeOfDay() {
  const weight = getRandomHourWeight();
  return !chance(weight * 100);
}

// Random commit message styles (70+ styles)
export function getRandomCommitMessage() {
  const styles = [
    // Conventional Commits (expanded)
    () => `feat: add ${faker.commerce.productAdjective()} ${faker.hacker.noun()}`,
    () => `fix: resolve ${faker.hacker.noun()} issue`,
    () => `docs: update ${faker.hacker.noun()} documentation`,
    () => `style: adjust ${faker.color.human()} theme`,
    () => `refactor: improve ${faker.hacker.noun()} structure`,
    () => `perf: optimize ${faker.hacker.verb()} performance`,
    () => `test: add ${faker.hacker.noun()} coverage`,
    () => `build: update dependencies`,
    () => `ci: ${faker.hacker.verb()} workflow`,
    () => `chore: ${faker.hacker.verb()} ${faker.hacker.noun()}`,
    () => `revert: undo ${faker.hacker.noun()} changes`,
    () => `merge: integrate ${faker.hacker.noun()} branch`,
    
    // Scoped commits
    () => `feat(${faker.hacker.noun()}): implement ${faker.hacker.verb()}`,
    () => `fix(${faker.hacker.noun()}): patch ${faker.hacker.adjective()} bug`,
    () => `docs(${faker.hacker.noun()}): clarify usage`,
    () => `refactor(${faker.hacker.noun()}): simplify logic`,
    () => `test(${faker.hacker.noun()}): expand coverage`,
    () => `chore(deps): bump ${faker.hacker.noun()}`,
    () => `ci(workflow): update ${faker.hacker.noun()}`,
    
    // Breaking changes
    () => `feat!: ${faker.hacker.phrase()}`,
    () => `refactor!: restructure ${faker.hacker.noun()}`,
    () => `BREAKING CHANGE: ${faker.hacker.verb()} ${faker.hacker.noun()}`,
    
    // Security & compliance
    () => `security: patch ${faker.hacker.noun()} vulnerability`,
    () => `security: update ${faker.hacker.noun()} dependencies`,
    () => `hotfix: critical ${faker.hacker.noun()} fix`,
    () => `audit: improve ${faker.hacker.noun()} compliance`,
    
    // Accessibility & i18n
    () => `a11y: improve ${faker.hacker.noun()} accessibility`,
    () => `i18n: add ${faker.location.country()} translations`,
    () => `i18n: update locale for ${faker.hacker.noun()}`,
    
    // Release & versioning
    () => `release: v${randomInt(1,3)}.${randomInt(0,9)}.${randomInt(0,9)}`,
    () => `bump: ${faker.hacker.noun()} to v${randomInt(1,5)}.x`,
    () => `release: prepare ${faker.commerce.productName()} launch`,
    
    // Web3 specific
    () => `contract: deploy ${faker.hacker.noun()} to mainnet`,
    () => `contract: optimize gas for ${faker.hacker.noun()}`,
    () => `web3: integrate ${faker.company.name()} protocol`,
    () => `dapp: add ${faker.hacker.noun()} functionality`,
    () => `nft: implement ${faker.commerce.productAdjective()} minting`,
    
    // Dependency management
    () => `deps: upgrade ${faker.hacker.noun()} to latest`,
    () => `deps(dev): update ${faker.hacker.noun()}`,
    () => `deps(security): patch vulnerabilities`,
    
    // Configuration
    () => `config: update ${faker.hacker.noun()} settings`,
    () => `env: add ${faker.hacker.noun()} variables`,
    () => `settings: configure ${faker.hacker.noun()}`,
    
    // Casual/informal
    () => `WIP: ${faker.hacker.phrase()}`,
    () => `quick fix`,
    () => `minor updates`,
    () => `cleanup`,
    () => `improvements`,
    () => `tweaks`,
    () => `polish ${faker.hacker.noun()}`,
    () => `update stuff`,
    () => `${faker.hacker.verb()} ${faker.hacker.noun()} - experimental`,
    
    // Emoji-style
    () => `✨ add ${faker.commerce.productAdjective()} feature`,
    () => `🐛 fix ${faker.hacker.noun()} bug`,
    () => `📝 update docs`,
    () => `🎨 improve UI/UX`,
    () => `⚡️ optimize performance`,
    () => `🔒 security update`,
    () => `🚀 deploy ${faker.hacker.noun()}`,
    
    // Team collaboration
    () => `review: address feedback on ${faker.hacker.noun()}`,
    () => `collab: integrate team changes`,
    () => `pair: implement ${faker.hacker.noun()} with team`,
    
    // Experimental/research
    () => `experiment: try ${faker.hacker.adjective()} approach`,
    () => `research: explore ${faker.hacker.noun()} options`,
    () => `spike: investigate ${faker.hacker.noun()}`,
    () => `prototype: ${faker.commerce.productName()} concept`
  ];
  
  return styles[randomInt(0, styles.length - 1)]();
}

// Random PR title styles
export function getRandomPRTitle() {
  const styles = [
    () => `[Auto] ${faker.hacker.phrase()}`,
    () => `✨ ${faker.commerce.productAdjective()} improvements`,
    () => `🔧 Fix: ${faker.hacker.noun()} updates`,
    () => `📝 Docs: ${faker.company.buzzPhrase()}`,
    () => `🚀 Feature: ${faker.hacker.verb()} ${faker.hacker.noun()}`,
    () => `⚡ Perf: optimize ${faker.hacker.noun()}`,
    () => `Automated contribution - ${new Date().toLocaleDateString()}`,
    () => `${faker.hacker.ingverb()} ${faker.hacker.noun()}`,
    () => `Update ${faker.hacker.noun()} functionality`,
    () => `Enhance ${faker.commerce.productAdjective()} features`
  ];
  
  return styles[randomInt(0, styles.length - 1)]();
}

// Random issue title
export function getRandomIssueTitle() {
  const types = [
    () => `Bug: ${faker.hacker.noun()} not ${faker.hacker.verb()}ing correctly`,
    () => `Feature request: Add ${faker.commerce.productAdjective()} ${faker.hacker.noun()}`,
    () => `Documentation: Clarify ${faker.hacker.noun()} usage`,
    () => `Question: How to ${faker.hacker.verb()} ${faker.hacker.noun()}?`,
    () => `Enhancement: Improve ${faker.hacker.noun()} performance`,
    () => `Refactor: ${faker.hacker.noun()} needs cleanup`,
    () => `Discussion: ${faker.company.buzzPhrase()}`,
    () => `[Help wanted] ${faker.hacker.phrase()}`,
    () => `Inconsistent ${faker.hacker.noun()} behavior`,
    () => `Add support for ${faker.commerce.productName()}`
  ];
  
  return types[randomInt(0, types.length - 1)]();
}

// Random file operation type
export function getRandomFileOp() {
  const ops = [
    'create',
    'update',
    'append',
    'tweak',
    'refactor'
  ];
  return ops[randomInt(0, ops.length - 1)];
}

// Weighted random: more likely to pick common operations
export function weightedRandomOp() {
  const rand = Math.random();
  
  if (rand < 0.50) return 'update';      // 50%
  if (rand < 0.75) return 'tweak';       // 25%
  if (rand < 0.90) return 'create';      // 15%
  if (rand < 0.97) return 'refactor';    // 7%
  return 'delete';                        // 3%
}

// Random technical buzzword
export function getRandomBuzzPhrase() {
  return faker.company.buzzPhrase();
}

// Simulate typing delays (characters per second)
export function getTypingDelay() {
  // Average human types 40-60 WPM (200-300 chars/min)
  // Add randomness: 150-400 chars/min
  const charsPerMin = randomInt(150, 400);
  return 60 / charsPerMin; // seconds per character
}

// Random label combinations (expanded)
export function getRandomLabels() {
  const labels = [
    // Bug related
    ['bug', 'high-priority'],
    ['bug', 'low-priority'],
    ['bug', 'critical'],
    ['bug', 'regression'],
    ['bug', 'needs-reproduction'],
    
    // Feature/Enhancement
    ['enhancement', 'good-first-issue'],
    ['feature', 'under-consideration'],
    ['feature', 'approved'],
    ['enhancement', 'breaking-change'],
    ['feature-request', 'needs-discussion'],
    
    // Documentation
    ['documentation', 'help-wanted'],
    ['docs', 'good-first-issue'],
    ['documentation', 'needs-update'],
    
    // Maintenance
    ['maintenance', 'dependencies'],
    ['refactor', 'tech-debt'],
    ['cleanup', 'code-quality'],
    
    // Web3 specific
    ['web3', 'smart-contract'],
    ['dapp', 'frontend'],
    ['nft', 'erc-721'],
    ['defi', 'protocol'],
    ['blockchain', 'gas-optimization'],
    
    // Status
    ['wip', 'in-progress'],
    ['needs-review'],
    ['ready-to-merge'],
    ['blocked'],
    ['on-hold'],
    
    // Priority
    ['high-priority', 'urgent'],
    ['low-priority'],
    ['p0-critical'],
    ['p1-important'],
    
    // Type
    ['question'],
    ['discussion'],
    ['proposal'],
    ['rfc'],
    
    // Quality
    ['security'],
    ['performance'],
    ['accessibility'],
    ['i18n'],
    
    // Resolution
    ['wontfix'],
    ['duplicate'],
    ['invalid'],
    ['works-as-intended'],
    
    // Community
    ['auto', 'discussion'],
    ['good-first-issue', 'help-wanted'],
    ['hacktoberfest'],
    ['community'],
    
    // Platform
    ['base-app'],
    ['farcaster'],
    ['mobile'],
    ['desktop'],
    ['backend'],
    ['frontend']
  ];
  
  return labels[randomInt(0, labels.length - 1)];
}

// Variable commit counts (1-5 files per commit)
export function getRandomFileCount() {
  const weights = [
    { count: 1, probability: 0.5 },   // 50% single file
    { count: 2, probability: 0.8 },   // 30% two files
    { count: 3, probability: 0.95 },  // 15% three files
    { count: 5, probability: 1.0 }    // 5% five files
  ];
  
  const rand = Math.random();
  for (const w of weights) {
    if (rand < w.probability) return w.count;
  }
  return 1;
}

// Random between Base dApp, Farcaster Frame, or Both
export function getMiniAppType() {
  const rand = Math.random();
  if (rand < 0.45) return 'base';
  if (rand < 0.90) return 'farcaster';
  return 'both'; // 10% chance to create both
}

// Should create mini app? (variable percentage by day)
export function shouldCreateMiniApp() {
  // More likely mid-week, less likely Mon/Fri
  const day = new Date().getDay();
  
  if (day === 0 || day === 6) return chance(20); // Weekend: 20%
  if (day === 1 || day === 5) return chance(40); // Mon/Fri: 40%
  return chance(60); // Tue-Thu: 60%
}

// Random pause between operations (simulate thinking time)
export function getThinkingPause() {
  return randomInt(2, 10); // 2-10 seconds
}

export default {
  chance,
  randomInt,
  randomDelay,
  shouldRunToday,
  shouldSkipByTimeOfDay,
  getRandomCommitMessage,
  getRandomPRTitle,
  getRandomIssueTitle,
  getRandomFileOp,
  weightedRandomOp,
  getRandomBuzzPhrase,
  getTypingDelay,
  getRandomLabels,
  getRandomFileCount,
  getMiniAppType,
  shouldCreateMiniApp,
  getThinkingPause,
  getRandomHourWeight
};
