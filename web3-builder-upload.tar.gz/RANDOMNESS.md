# Randomness Features

## Overview
The system now uses sophisticated randomness to simulate human-like behavior patterns.

## Key Randomness Features

### 1. Time-of-Day Awareness
Activity varies by UTC hour to mimic human work patterns:
- **Night (0-6 UTC)**: 10% activity
- **Morning (6-9 UTC)**: 40% activity  
- **Peak work (9-17 UTC)**: 90% activity
- **Evening (17-22 UTC)**: 60% activity
- **Late night (22-24 UTC)**: 20% activity

### 2. Day-of-Week Patterns
- **Weekdays**: 85% chance to run
- **Weekends**: 30% chance to run

### 3. Variable Mini App Generation
Not a fixed 50%, but varies by day:
- **Weekend**: 20% chance
- **Monday/Friday**: 40% chance
- **Tuesday-Thursday**: 60% chance

### 4. Mini App Type Distribution
When generating:
- **Base dApp only**: 45%
- **Farcaster Frame only**: 45%
- **Both**: 10%

### 5. Random Commit Messages
18 different commit message styles:
```
chore: synthesize port
feat: add Sleek protocol
fix: resolve bandwidth issue
docs: update matrix documentation
refactor: improve firewall structure
WIP: Cross-platform optimal emulation
quick fix
minor updates
...and more
```

### 6. Random PR Titles
10 different PR title formats:
```
[Auto] Cross-platform optimal emulation
✨ Sleek improvements
🔧 Fix: port updates
📝 Docs: Innovative next-generation standardization
🚀 Feature: synthesize matrix
...and more
```

### 7. Random Issue Titles
10 different issue patterns:
```
Bug: port not synthesizing correctly
Feature request: Add Sleek matrix
Documentation: Clarify bandwidth usage
Question: How to synthesize firewall?
Enhancement: Improve protocol performance
...and more
```

### 8. Variable Issue Probabilities
- **Create issue**: 25% chance (up from 20%)
- **Close issue**: 15% chance (up from 10%)

### 9. Random Issue Labels
10 different label combinations:
```
['bug', 'high-priority']
['enhancement', 'good-first-issue']
['documentation', 'help-wanted']
['question']
['feature', 'under-consideration']
['wontfix']
['duplicate']
['auto', 'discussion']
['performance']
['security']
```

### 10. Variable Delays
- **Workflow delay**: 0-20 minutes (was 0-15)
- **Thinking pause**: 2-10 seconds between operations

### 11. Human Edit Variations
Multiple styles of README edits:
```markdown
Note: Inverse zero administration hierarchy
> Seamless next-generation leverage
## Sleek Update
Intuitive regional framework
<!-- Cross-platform optimal emulation -->
**orchestrate** convergence
```

Comment styles for code:
```javascript
// Seamless next-generation leverage
// TODO: synthesize port
/* Intuitive regional framework */
// FIXME: optimize bandwidth
```

### 12. Variable Edit Chances
- **README tweak**: 40-70% (randomized each run)
- **Frontend tweak**: 20-50% (randomized each run)
- **NOTES.md creation**: 10%

### 13. Typing Speed Simulation
Random typing delay: 150-400 characters per minute (human range)

### 14. Weighted File Operations
Not all operations equally likely:
- **update**: 50%
- **tweak**: 25%
- **create**: 15%
- **refactor**: 7%
- **delete**: 3%

## Usage Examples

```javascript
import { 
  chance, 
  randomInt, 
  getRandomCommitMessage,
  shouldCreateMiniApp,
  getRandomPRTitle
} from './randomness.mjs';

// 30% chance
if (chance(30)) {
  console.log('Lucky!');
}

// Random number 1-10
const n = randomInt(1, 10);

// Get commit message
const msg = getRandomCommitMessage();

// Should create mini app? (varies by day)
if (shouldCreateMiniApp()) {
  // generate...
}
```

## Benefits

✅ **Unpredictable**: No fixed patterns  
✅ **Human-like**: Mimics real developer behavior  
✅ **Time-aware**: Activity matches human work hours  
✅ **Varied content**: Different messages/titles each time  
✅ **Natural distribution**: Weighted probabilities  
✅ **Safe**: Still respects daily caps  

## Testing

```bash
# Test randomness functions
node -e "import('./randomness.mjs').then(m=>{
  console.log('Commit:', m.getRandomCommitMessage());
  console.log('PR:', m.getRandomPRTitle());
  console.log('Issue:', m.getRandomIssueTitle());
  console.log('Should run?', !m.shouldSkipByTimeOfDay());
  console.log('Create miniapp?', m.shouldCreateMiniApp());
  console.log('Type:', m.getMiniAppType());
})"
```

## Result

The system now exhibits genuinely human-like patterns:
- Natural timing variation
- Unpredictable message styles
- Context-aware behavior
- Realistic work patterns
- Varied content generation
