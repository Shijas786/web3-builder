import fs from "fs";
import { faker } from "@faker-js/faker";
import { getMiniAppType } from "./randomness.mjs";

const timestamp = new Date().toISOString().replace(/[:.]/g, "-");

// Randomly choose mini app type with weighting
const appType = getMiniAppType();

if (appType === "base") {
  generateBaseDapp();
} else if (appType === "farcaster") {
  generateFarcasterFrame();
} else {
  // Generate both!
  generateBaseDapp();
  generateFarcasterFrame();
}

function generateBaseDapp() {
  const appName = faker.commerce.productName().replace(/\s+/g, "-").toLowerCase();
  const dir = `miniapps/base-${appName}-${timestamp}`;
  
  fs.mkdirSync(dir, { recursive: true });
  
  // Package.json with OnchainKit
  fs.writeFileSync(`${dir}/package.json`, JSON.stringify({
    "name": appName,
    "version": "0.1.0",
    "type": "module",
    "scripts": {
      "dev": "vite",
      "build": "vite build",
      "preview": "vite preview"
    },
    "dependencies": {
      "@coinbase/onchainkit": "latest",
      "viem": "^2.0.0",
      "react": "^18.3.0",
      "react-dom": "^18.3.0"
    },
    "devDependencies": {
      "@vitejs/plugin-react": "^4.3.0",
      "vite": "^5.0.0"
    }
  }, null, 2));

  // Smart contract
  fs.writeFileSync(`${dir}/Contract.sol`, `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract ${toPascalCase(appName)} {
    string public name = "${appName}";
    uint256 public counter;
    
    event Incremented(uint256 newValue);
    
    function increment() public {
        counter++;
        emit Incremented(counter);
    }
    
    function getCounter() public view returns (uint256) {
        return counter;
    }
}
`);

  // App.tsx with MiniKit integration
  fs.writeFileSync(`${dir}/App.tsx`, `'use client';

import { useMiniKit } from '@coinbase/onchainkit/minikit';
import { useEffect, useState } from 'react';

export default function ${toPascalCase(appName)}App() {
  const { context, isFrameReady, setFrameReady } = useMiniKit();
  const [counter, setCounter] = useState(0);

  useEffect(() => {
    if (!isFrameReady) {
      setFrameReady();
    }
  }, [setFrameReady, isFrameReady]);

  const increment = async () => {
    // TODO: Call smart contract via OnchainKit
    setCounter(c => c + 1);
  };

  return (
    <div style={{ 
      fontFamily: 'system-ui', 
      maxWidth: '600px', 
      margin: '50px auto', 
      padding: '20px' 
    }}>
      <h1>${appName}</h1>
      <p>${faker.company.catchPhrase()}</p>
      
      {context && (
        <div style={{ marginBottom: '20px', fontSize: '14px', color: '#666' }}>
          <p>👤 User FID: {context.user.fid}</p>
          <p>📍 Launched from: {context.location}</p>
          {context.client.added && <p>✅ App saved!</p>}
        </div>
      )}
      
      <div style={{ 
        fontSize: '48px', 
        margin: '20px 0', 
        color: '#0052FF' 
      }}>
        {counter}
      </div>
      
      <button 
        onClick={increment}
        style={{
          padding: '12px 24px',
          fontSize: '16px',
          cursor: 'pointer',
          background: '#0052FF',
          color: 'white',
          border: 'none',
          borderRadius: '8px'
        }}
      >
        Increment
      </button>
    </div>
  );
}
`);

  // Main entry point
  fs.writeFileSync(`${dir}/main.tsx`, `import React from 'react';
import ReactDOM from 'react-dom/client';
import { MiniKitProvider } from '@coinbase/onchainkit/minikit';
import App from './App';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <MiniKitProvider>
      <App />
    </MiniKitProvider>
  </React.StrictMode>
);
`);

  // index.html
  fs.writeFileSync(`${dir}/index.html`, `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${appName} - Base Mini App</title>
  <link rel="preconnect" href="https://auth.farcaster.xyz">
</head>
<body>
  <div id="root"></div>
  <script type="module" src="/main.tsx"></script>
</body>
</html>
`);

  // Vite config
  fs.writeFileSync(`${dir}/vite.config.ts`, `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
});
`);

  fs.writeFileSync(`${dir}/README.md`, `# ${appName}

Base Mini App with OnchainKit integration. Generated on ${new Date().toISOString()}.

## Features
- ✅ Base MiniKit SDK integration
- ✅ User context (FID, location, saved status)
- ✅ Frame readiness handling
- ✅ Counter smart contract
- ✅ React + Vite setup

## Setup
\`\`\`bash
npm install
npm run dev
\`\`\`

## Deploy Contract
\`\`\`bash
forge create --rpc-url https://base-mainnet.g.alchemy.com/v2/YOUR_KEY \\
  --private-key YOUR_PRIVATE_KEY \\
  Contract.sol:${toPascalCase(appName)}
\`\`\`

## Resources
- [Base Mini Apps Docs](https://docs.base.org/mini-apps/)
- [OnchainKit MiniKit](https://docs.base.org/mini-apps/technical-reference/minikit/hooks/useMiniKit)
- [Base Developer Portal](https://base.org)
`);

  console.log(`✅ Base dApp created: ${dir}`);
}

function generateFarcasterFrame() {
  const frameName = faker.hacker.noun().replace(/\s+/g, "-").toLowerCase();
  const dir = `miniapps/farcaster-${frameName}-${timestamp}`;
  
  fs.mkdirSync(dir, { recursive: true });
  
  // Package.json with Farcaster MiniApp SDK
  fs.writeFileSync(`${dir}/package.json`, JSON.stringify({
    "name": `farcaster-${frameName}`,
    "version": "0.1.0",
    "type": "module",
    "scripts": {
      "dev": "vite",
      "build": "vite build",
      "preview": "vite preview"
    },
    "dependencies": {
      "@farcaster/miniapp-sdk": "latest",
      "react": "^18.3.0",
      "react-dom": "^18.3.0"
    },
    "devDependencies": {
      "@vitejs/plugin-react": "^4.3.0",
      "vite": "^5.0.0"
    }
  }, null, 2));

  // App.tsx with MiniApp SDK
  fs.writeFileSync(`${dir}/App.tsx`, `import { sdk } from '@farcaster/miniapp-sdk';
import { useEffect, useState } from 'react';

export default function ${toPascalCase(frameName)}App() {
  const [context, setContext] = useState<any>(null);
  const [authenticated, setAuthenticated] = useState(false);

  useEffect(() => {
    // Signal ready to hide splash screen
    sdk.actions.ready();
    
    // Get context
    const ctx = sdk.context;
    setContext(ctx);
    
    console.log('Farcaster Mini App loaded', {
      user: ctx?.user,
      client: ctx?.client,
    });
  }, []);

  const handleAuth = async () => {
    try {
      const token = await sdk.quickAuth.getToken();
      setAuthenticated(true);
      console.log('Authenticated with token:', token);
      
      // TODO: Send token to your backend for verification
      // const response = await fetch('/api/me', {
      //   headers: { 'Authorization': \`Bearer \${token}\` }
      // });
    } catch (error) {
      console.error('Auth failed:', error);
    }
  };

  const handleOpenProfile = () => {
    if (context?.user?.fid) {
      sdk.actions.openUrl(\`https://warpcast.com/\${context.user.username || context.user.fid}\`);
    }
  };

  return (
    <div style={{
      fontFamily: 'system-ui',
      maxWidth: '800px',
      margin: '50px auto',
      padding: '20px',
      background: '#f5f5f5'
    }}>
      <div style={{
        background: 'white',
        padding: '30px',
        borderRadius: '12px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
      }}>
        <h1 style={{ color: '#8A63D2' }}>🎯 ${frameName}</h1>
        <p>${faker.company.catchPhrase()}</p>
        
        {context && (
          <div style={{ 
            marginTop: '20px', 
            padding: '15px', 
            background: '#f9f9f9', 
            borderRadius: '8px' 
          }}>
            <p><strong>User FID:</strong> {context.user?.fid}</p>
            <p><strong>Username:</strong> @{context.user?.username || 'unknown'}</p>
            <p><strong>Client:</strong> {context.client?.clientFid === '1' ? 'Warpcast' : 'Farcaster'}</p>
            
            <div style={{ marginTop: '15px', display: 'flex', gap: '10px' }}>
              <button
                onClick={handleAuth}
                disabled={authenticated}
                style={{
                  padding: '10px 20px',
                  background: authenticated ? '#28a745' : '#8A63D2',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: authenticated ? 'default' : 'pointer'
                }}
              >
                {authenticated ? '✓ Authenticated' : 'Authenticate'}
              </button>
              
              <button
                onClick={handleOpenProfile}
                style={{
                  padding: '10px 20px',
                  background: '#007bff',
                  color: 'white',
                  border: 'none',
                  borderRadius: '6px',
                  cursor: 'pointer'
                }}
              >
                View Profile
              </button>
            </div>
          </div>
        )}
        
        <div style={{ marginTop: '20px', fontSize: '14px', color: '#666' }}>
          <p><strong>Generated:</strong> ${new Date().toISOString()}</p>
        </div>
      </div>
    </div>
  );
}
`);

  // Main entry
  fs.writeFileSync(`${dir}/main.tsx`, `import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
`);

  // index.html
  fs.writeFileSync(`${dir}/index.html`, `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${frameName} - Farcaster Mini App</title>
</head>
<body>
  <div id="root"></div>
  <script type="module" src="/main.tsx"></script>
</body>
</html>
`);

  // Vite config
  fs.writeFileSync(`${dir}/vite.config.ts`, `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
});
`);

  fs.writeFileSync(`${dir}/README.md`, `# ${frameName} - Farcaster Mini App

Interactive Farcaster Mini App using official SDK. Generated on ${new Date().toISOString()}.

## Features
- ✅ Farcaster MiniApp SDK integration
- ✅ Quick Auth authentication
- ✅ User context access (FID, username, client)
- ✅ \`sdk.actions.ready()\` for splash screen handling
- ✅ Profile viewing via \`sdk.actions.openUrl()\`
- ✅ React + TypeScript + Vite

## Setup
\`\`\`bash
npm install
npm run dev
\`\`\`

## Authentication Flow
The app uses [Quick Auth](https://miniapps.farcaster.xyz/docs/sdk/quick-auth) which is built on Sign In with Farcaster (SIWF):

1. Click "Authenticate" button
2. \`sdk.quickAuth.getToken()\` gets a signed JWT session token
3. Send token to your backend with \`Authorization: Bearer <token>\` header
4. Validate token on server using \`@farcaster/quick-auth\`

## Backend Validation Example
\`\`\`typescript
import { createClient } from '@farcaster/quick-auth';

const client = createClient();
const payload = await client.verifyJwt({ 
  token: authToken, 
  domain: 'yourdomain.com' 
});
console.log('User FID:', payload.sub);
\`\`\`

## Deploy
1. Build: \`npm run build\`
2. Deploy \`dist/\` to Vercel/Netlify
3. Enable Developer Mode in Farcaster client
4. Create manifest at farcaster.xyz/~/settings/developer-tools

## Resources
- [Farcaster Mini Apps Docs](https://miniapps.farcaster.xyz/)
- [Quick Auth Guide](https://miniapps.farcaster.xyz/docs/sdk/quick-auth)
- [SDK Reference](https://miniapps.farcaster.xyz/docs/sdk/actions)
- [Developer Tools](https://farcaster.xyz/~/settings/developer-tools)
`);

  console.log(`✅ Farcaster Frame created: ${dir}`);
}

function toPascalCase(str) {
  return str.replace(/(^\w|-\w)/g, m => m.replace('-', '').toUpperCase());
}
