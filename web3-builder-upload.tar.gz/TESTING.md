# Testing Guide

## Quick Test Commands

### 1. Test All Core Scripts Locally
```bash
# Test the main generator
npm start

# Test mini app generation
npm run miniapp

# Test human-like edits
npm run human

# Test randomness functions
npm run test:random
```

### 2. Test GitHub Integration (requires env vars)
```bash
# Set environment variables
export GITHUB_TOKEN="your_personal_access_token"
export GITHUB_OWNER="your_github_username"
export GITHUB_REPO="your_repo_name"
export GITHUB_ACTOR="your_username"

# Test PR creation (won't actually create without a remote)
node -e "import('./github.mjs').then(m => m.createPR('test-branch', 'Test PR', process.env.GITHUB_OWNER))"

# Test issue operations
node -e "import('./github.mjs').then(m => m.maybeCreateIssue())"
node -e "import('./github.mjs').then(m => m.maybeCloseIssue())"
```

### 3. Test Full Workflow Locally
```bash
# Run the complete flow (without GitHub push)
npm run test:full
```

---

## Detailed Testing

### Test 1: Basic File Generation

**What it tests:** Core generator creates files correctly

```bash
# Clean start
rm -rf CHANGELOG.md

# Run generator
node generate_and_commit.mjs

# Verify
cat CHANGELOG.md
cat README.md
```

**Expected output:**
- `CHANGELOG.md` created with timestamp entry
- `README.md` ensured (created if missing)

---

### Test 2: Mini App Generation

**What it tests:** Mini apps created with proper structure

```bash
# Generate mini app
node generate_miniapp.mjs

# Check structure
ls -la miniapps/
```

**Expected output:**
```
miniapps/
├── base-{name}-{timestamp}/          (45% chance)
│   ├── package.json                  ✅ OnchainKit deps
│   ├── App.tsx                       ✅ useMiniKit hook
│   ├── main.tsx                      ✅ MiniKitProvider
│   ├── Contract.sol                  ✅ Solidity
│   ├── index.html                    ✅ Preconnect
│   ├── vite.config.ts               ✅ Vite config
│   └── README.md                     ✅ Docs
│
└── farcaster-{name}-{timestamp}/     (45% chance)
    ├── package.json                  ✅ @farcaster/miniapp-sdk
    ├── App.tsx                       ✅ Quick Auth
    ├── main.tsx                      ✅ React entry
    ├── index.html                    ✅ HTML
    ├── vite.config.ts               ✅ Vite config
    └── README.md                     ✅ Auth docs
```

**Verify SDK integration:**
```bash
# Check Base app has OnchainKit
grep "@coinbase/onchainkit" miniapps/base-*/package.json

# Check Farcaster app has SDK
grep "@farcaster/miniapp-sdk" miniapps/farcaster-*/package.json

# Check useMiniKit in Base app
grep "useMiniKit" miniapps/base-*/App.tsx

# Check Quick Auth in Farcaster app
grep "quickAuth" miniapps/farcaster-*/App.tsx
```

---

### Test 3: Human-like Edits

**What it tests:** Random tweaks and variations

```bash
# Run multiple times to see variations
for i in {1..5}; do
  echo "Run $i:"
  node human_edit.mjs
done

# Check README changes
git diff README.md

# Check if NOTES.md created (10% chance)
ls NOTES.md 2>/dev/null && echo "✅ NOTES.md created" || echo "⏭️  NOTES.md not created this time"
```

**Expected behaviors:**
- README tweaked with varied styles (40-70% chance)
- Frontend files tweaked if they exist (20-50% chance)
- NOTES.md created occasionally (10% chance)
- Different message styles each run

---

### Test 4: Randomness Module

**What it tests:** All randomness functions work correctly

```bash
# Test all randomness features
node -e "
import('./randomness.mjs').then(m => {
  console.log('=== Randomness Test ===');
  console.log('Commit:', m.getRandomCommitMessage());
  console.log('PR Title:', m.getRandomPRTitle());
  console.log('Issue Title:', m.getRandomIssueTitle());
  console.log('Labels:', m.getRandomLabels());
  console.log('Mini App Type:', m.getMiniAppType());
  console.log('Should create mini app?', m.shouldCreateMiniApp());
  console.log('Should run today?', m.shouldRunToday());
  console.log('Skip by time?', m.shouldSkipByTimeOfDay());
  console.log('Hour weight:', m.getRandomHourWeight());
  console.log('Random 1-10:', m.randomInt(1, 10));
  console.log('30% chance:', m.chance(30));
  console.log('File op:', m.getRandomFileOp());
  console.log('Weighted op:', m.weightedRandomOp());
  console.log('Buzz phrase:', m.getRandomBuzzPhrase());
});
"
```

**Run multiple times to verify variety:**
```bash
for i in {1..3}; do
  echo "=== Run $i ==="
  npm run test:random
  echo ""
done
```

---

### Test 5: GitHub API Integration

**Prerequisites:**
1. Create a test repository
2. Generate GitHub PAT with `repo` scope
3. Set environment variables

**Setup:**
```bash
export GITHUB_TOKEN="ghp_yourtoken"
export GITHUB_OWNER="yourusername"
export GITHUB_REPO="test-repo"
export GITHUB_ACTOR="yourusername"
```

**Test daily caps:**
```bash
# Test PR cap counting
node -e "
import('./github.mjs').then(async (m) => {
  const count = await m._internal.countTodayPRsByActor();
  console.log('PRs created today:', count);
});
"

# Test issue cap counting
node -e "
import('./github.mjs').then(async (m) => {
  const created = await m._internal.countTodayIssuesCreatedByActor();
  const closed = await m._internal.countTodayIssuesClosedByActor();
  console.log('Issues created today:', created);
  console.log('Issues closed today:', closed);
});
"
```

---

### Test 6: Complete Local Workflow

**What it tests:** Full automation pipeline without push

```bash
# Initialize git if needed
git init

# Run complete workflow
echo "1. Generate changes..."
node generate_and_commit.mjs

echo "2. Generate mini app..."
node generate_miniapp.mjs

echo "3. Human-like tweaks..."
node human_edit.mjs

echo "4. Check changes..."
git status

echo "5. Create commit..."
MSG=$(node -e "import('./randomness.mjs').then(m=>console.log(m.getRandomCommitMessage()))")
git add .
git commit -m "$MSG" || echo "No changes to commit"

echo "✅ Workflow complete!"
```

---

### Test 7: Generated Mini Apps (Development)

**Test Base Mini App:**
```bash
# Navigate to generated Base app
cd miniapps/base-*/

# Install dependencies
npm install

# Start dev server
npm run dev

# Open http://localhost:5173
# You should see:
# - App title
# - User context (may be undefined in browser)
# - Counter
# - Increment button
```

**Test Farcaster Mini App:**
```bash
# Navigate to generated Farcaster app
cd miniapps/farcaster-*/

# Install dependencies
npm install

# Start dev server
npm run dev

# Open http://localhost:5173
# You should see:
# - App title
# - User info section
# - Authenticate button
# - View Profile button
```

**Note:** Full SDK features only work when deployed and accessed from Base App or Farcaster clients.

---

### Test 8: GitHub Actions (Dry Run)

**Validate workflow syntax:**
```bash
# Install act (GitHub Actions local runner)
# macOS: brew install act
# Linux: curl https://raw.githubusercontent.com/nektos/act/master/install.sh | sudo bash

# Dry run the workflow
act workflow_dispatch --secret GITHUB_TOKEN=$GITHUB_TOKEN -n

# See what would run
act workflow_dispatch --list
```

**Check workflow file:**
```bash
# Validate YAML syntax
cat .github/workflows/auto-collab.yml | npx js-yaml

# Check for issues
grep -E "(TODO|FIXME|XXX)" .github/workflows/auto-collab.yml
```

---

### Test 9: Production Deployment Test

**Prerequisites:**
1. Push code to GitHub
2. Configure secrets in repo settings
3. Enable GitHub Actions

**Required Secrets:**
- `GITHUB_TOKEN` (auto-provided or PAT)
- `DEPLOY_ENABLED` (optional)
- `FORK_OWNER` (if using fork flow)

**Optional Variables:**
- `ENABLE_FORK_FLOW` = `true` (for fork-based PRs)

**Test workflow manually:**
1. Go to repo → Actions
2. Select "Auto Collab Contributions"
3. Click "Run workflow"
4. Wait for completion
5. Check for:
   - ✅ Branch created
   - ✅ Files modified
   - ✅ PR opened
   - ✅ Issue created (25% chance)

---

## Automated Test Script

Create `test-all.sh`:

```bash
#!/bin/bash
set -e

echo "🧪 Running all tests..."
echo ""

# Test 1: Generators
echo "1️⃣  Testing generators..."
node generate_and_commit.mjs
node generate_miniapp.mjs
echo "✅ Generators passed"
echo ""

# Test 2: Human edits
echo "2️⃣  Testing human edits..."
node human_edit.mjs
echo "✅ Human edits passed"
echo ""

# Test 3: Randomness
echo "3️⃣  Testing randomness..."
npm run test:random
echo "✅ Randomness passed"
echo ""

# Test 4: Git operations
echo "4️⃣  Testing git operations..."
git add -A
MSG=$(node -e "import('./randomness.mjs').then(m=>console.log(m.getRandomCommitMessage()))")
git commit -m "$MSG" || echo "No changes (ok)"
echo "✅ Git operations passed"
echo ""

echo "🎉 All tests passed!"
```

Make executable and run:
```bash
chmod +x test-all.sh
./test-all.sh
```

---

## Verification Checklist

After running tests, verify:

### Files Created
- [ ] `CHANGELOG.md` exists with entries
- [ ] `README.md` exists (may be tweaked)
- [ ] `miniapps/` directory exists
- [ ] Mini apps have all required files
- [ ] `NOTES.md` may exist (10% chance)

### Mini App Structure
- [ ] Base apps have `@coinbase/onchainkit` in package.json
- [ ] Base apps have `useMiniKit()` in App.tsx
- [ ] Farcaster apps have `@farcaster/miniapp-sdk` in package.json
- [ ] Farcaster apps have Quick Auth implementation
- [ ] All apps have proper TypeScript setup
- [ ] All apps have Vite configuration

### Randomness
- [ ] Commit messages vary each run
- [ ] PR titles are different
- [ ] Issue titles are varied
- [ ] Mini app type distribution is weighted (45/45/10)
- [ ] Time-of-day awareness works

### GitHub Integration (if testing with API)
- [ ] Daily caps are enforced
- [ ] PRs created with random titles
- [ ] Issues created with random titles/labels
- [ ] Issues closed randomly

---

## Troubleshooting

### Issue: `Missing GITHUB_TOKEN`
**Solution:** Set environment variable or test without GitHub features

### Issue: Mini app generation always creates same type
**Solution:** This is random - run multiple times to see variety

### Issue: No files modified by human_edit.mjs
**Solution:** It's probabilistic (40-70% chance) - run multiple times

### Issue: Workflow doesn't run on schedule
**Solution:** Check repo settings → Actions → allow workflows

### Issue: Cannot install mini app dependencies
**Solution:** The mini apps are templates - install deps after generation

---

## Next Steps

After local testing passes:
1. Push to GitHub
2. Configure secrets
3. Enable Actions
4. Run workflow manually
5. Monitor scheduled runs
6. Review generated PRs/issues

## CI/CD Recommendation

For production:
1. Add linting to mini app templates
2. Add tests for randomness functions
3. Mock GitHub API in tests
4. Add workflow validation in CI
