#!/bin/bash

# 🏆 Talent Protocol Deployment Script
# Automates the setup process for maximum weekly rewards

set -e

echo "╔══════════════════════════════════════════════════════════════════════════╗"
echo "║         🏆 TALENT PROTOCOL WEB3 BUILDER DEPLOYMENT 🏆                   ║"
echo "╚══════════════════════════════════════════════════════════════════════════╝"
echo ""

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Check if gh CLI is installed
if ! command -v gh &> /dev/null; then
    echo -e "${YELLOW}⚠️  GitHub CLI not found. Install it for easier setup:${NC}"
    echo "   macOS: brew install gh"
    echo "   Linux: See https://cli.github.com/manual/installation"
    echo ""
    USE_GH=false
else
    echo -e "${GREEN}✅ GitHub CLI found${NC}"
    USE_GH=true
fi

# Get GitHub username
echo -e "${BLUE}📝 Enter your GitHub username:${NC}"
read -p "Username: " GITHUB_USERNAME

if [ -z "$GITHUB_USERNAME" ]; then
    echo -e "${RED}❌ Username is required${NC}"
    exit 1
fi

echo ""
echo -e "${BLUE}🔑 Do you have a GitHub Personal Access Token ready?${NC}"
echo "   (With 'repo' and 'workflow' scopes)"
read -p "Enter token (or press Enter to get instructions): " GITHUB_TOKEN

if [ -z "$GITHUB_TOKEN" ]; then
    echo ""
    echo -e "${YELLOW}📋 To create a token:${NC}"
    echo "1. Go to: https://github.com/settings/tokens"
    echo "2. Click 'Generate new token (classic)'"
    echo "3. Select scopes: 'repo' and 'workflow'"
    echo "4. Copy the token"
    echo ""
    read -p "Paste your token here: " GITHUB_TOKEN
    
    if [ -z "$GITHUB_TOKEN" ]; then
        echo -e "${RED}❌ Token is required${NC}"
        exit 1
    fi
fi

echo ""
echo -e "${GREEN}✅ Configuration received${NC}"
echo ""

# Export for gh CLI
export GH_TOKEN=$GITHUB_TOKEN

# Initialize git if not already
if [ ! -d ".git" ]; then
    echo -e "${BLUE}📦 Initializing git repository...${NC}"
    git init
    git add .
    git commit -m "feat: initialize web3 builder for Talent Protocol"
    git branch -M main
    echo -e "${GREEN}✅ Git repository initialized${NC}"
else
    echo -e "${GREEN}✅ Git repository already initialized${NC}"
fi

# Create main repo
REPO_NAME="web3-builder"
echo ""
echo -e "${BLUE}🚀 Creating main repository: $REPO_NAME${NC}"

if [ "$USE_GH" = true ]; then
    # Use gh CLI
    gh repo create "$REPO_NAME" --public --description "Web3 Builder Automation for Talent Protocol" --source=. --remote=origin --push 2>/dev/null || {
        echo -e "${YELLOW}⚠️  Repo might already exist, trying to add remote...${NC}"
        git remote add origin "https://github.com/$GITHUB_USERNAME/$REPO_NAME.git" 2>/dev/null || true
        git push -u origin main
    }
else
    # Manual instructions
    echo -e "${YELLOW}📋 Manual steps:${NC}"
    echo "1. Go to: https://github.com/new"
    echo "2. Repository name: $REPO_NAME"
    echo "3. Visibility: Public"
    echo "4. DON'T initialize with README"
    echo "5. Click 'Create repository'"
    echo ""
    read -p "Press Enter when repo is created..."
    
    git remote add origin "https://github.com/$GITHUB_USERNAME/$REPO_NAME.git" 2>/dev/null || true
    git push -u origin main
fi

echo -e "${GREEN}✅ Main repository created and pushed${NC}"

# Configure secrets
echo ""
echo -e "${BLUE}🔐 Configuring repository secrets...${NC}"

if [ "$USE_GH" = true ]; then
    echo "$GITHUB_TOKEN" | gh secret set GITHUB_TOKEN --repo="$GITHUB_USERNAME/$REPO_NAME"
    echo -e "${GREEN}✅ GITHUB_TOKEN secret configured${NC}"
else
    echo -e "${YELLOW}📋 Manual step:${NC}"
    echo "1. Go to: https://github.com/$GITHUB_USERNAME/$REPO_NAME/settings/secrets/actions"
    echo "2. Click 'New repository secret'"
    echo "3. Name: GITHUB_TOKEN"
    echo "4. Value: $GITHUB_TOKEN"
    echo ""
    read -p "Press Enter when secret is configured..."
fi

# Optional: Create additional repos
echo ""
echo -e "${BLUE}📚 Do you want to create additional repos for more activity?${NC}"
read -p "Create web3-portfolio and web3-contracts? (y/n): " CREATE_MORE

if [[ $CREATE_MORE =~ ^[Yy]$ ]]; then
    echo ""
    echo -e "${BLUE}Creating additional repositories...${NC}"
    
    for repo in "web3-portfolio" "web3-contracts"; do
        if [ "$USE_GH" = true ]; then
            gh repo create "$repo" --public --description "Web3 Projects Collection" 2>/dev/null && \
                echo -e "${GREEN}✅ Created $repo${NC}" || \
                echo -e "${YELLOW}⚠️  $repo might already exist${NC}"
        else
            echo "Create manually: https://github.com/new"
            echo "Name: $repo"
            echo ""
        fi
    done
fi

# Enable Actions
echo ""
echo -e "${BLUE}⚙️  Enabling GitHub Actions...${NC}"
echo "   Go to: https://github.com/$GITHUB_USERNAME/$REPO_NAME/actions"
echo "   Click: 'I understand my workflows, go ahead and enable them'"
read -p "Press Enter when Actions are enabled..."

# Test workflow
echo ""
echo -e "${BLUE}🧪 Do you want to test the workflow now?${NC}"
read -p "Run a test workflow? (y/n): " RUN_TEST

if [[ $RUN_TEST =~ ^[Yy]$ ]]; then
    if [ "$USE_GH" = true ]; then
        gh workflow run talent-boost.yml --repo="$GITHUB_USERNAME/$REPO_NAME"
        echo -e "${GREEN}✅ Workflow started!${NC}"
        echo "   Check: https://github.com/$GITHUB_USERNAME/$REPO_NAME/actions"
    else
        echo "   Go to: https://github.com/$GITHUB_USERNAME/$REPO_NAME/actions"
        echo "   Select: 'Talent Protocol Activity Boost'"
        echo "   Click: 'Run workflow'"
    fi
fi

# Summary
echo ""
echo "╔══════════════════════════════════════════════════════════════════════════╗"
echo "║                     ✅ DEPLOYMENT COMPLETE! ✅                           ║"
echo "╚══════════════════════════════════════════════════════════════════════════╝"
echo ""
echo -e "${GREEN}🎉 Your Web3 Builder is deployed and ready!${NC}"
echo ""
echo "📊 Next Steps:"
echo "   1. Check your GitHub profile for contribution activity"
echo "   2. Update your Talent Protocol profile"
echo "   3. Monitor Actions for workflow runs"
echo "   4. Add some real projects alongside automation"
echo ""
echo "🔗 Important Links:"
echo "   • Your repo: https://github.com/$GITHUB_USERNAME/$REPO_NAME"
echo "   • Actions: https://github.com/$GITHUB_USERNAME/$REPO_NAME/actions"
echo "   • Contribution graph: https://github.com/$GITHUB_USERNAME"
echo "   • Talent Protocol: https://passport.talentprotocol.com"
echo ""
echo "📚 Documentation:"
echo "   • Setup guide: TALENT_PROTOCOL_SETUP.md"
echo "   • Testing: TESTING.md"
echo "   • Features: FEATURES.md"
echo ""
echo -e "${BLUE}🏆 Start earning those Talent Protocol rewards! 🏆${NC}"
echo ""
