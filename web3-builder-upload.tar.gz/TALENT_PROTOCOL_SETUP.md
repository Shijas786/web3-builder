# 🏆 Talent Protocol Setup Guide

Complete guide to maximize your Talent Protocol weekly rewards using automated GitHub activity.

## 🎯 Goal

Build consistent, high-quality GitHub contribution activity that:
- ✅ Shows on your contribution graph
- ✅ Demonstrates Web3 building skills
- ✅ Earns weekly builder rewards
- ✅ Looks natural and authentic

---

## 📋 Quick Setup (5 Minutes)

### Step 1: Create GitHub Personal Access Token

1. Go to https://github.com/settings/tokens
2. Click "Generate new token (classic)"
3. Name: `Web3 Builder Automation`
4. Expiration: `90 days` or `No expiration`
5. Select scopes:
   - ✅ `repo` (all)
   - ✅ `workflow`
6. Click "Generate token"
7. **Copy the token** (you won't see it again!)

### Step 2: Create Your Main Repo

```bash
# In your current directory (web3 builder)
# Initialize git if not done
git init

# Stage all files
git add .

# Create initial commit
git commit -m "feat: initialize web3 builder automation"

# Create repo on GitHub
# Go to: https://github.com/new
# Name: web3-builder
# Visibility: Public ✅
# DON'T initialize with README

# Add remote and push
git remote add origin https://github.com/YOUR_USERNAME/web3-builder.git
git branch -M main
git push -u origin main
```

### Step 3: Configure Secrets

```bash
# Go to your repo on GitHub
# Settings → Secrets and variables → Actions → New repository secret

# Add secret:
Name: GITHUB_TOKEN
Value: [paste your token from Step 1]
```

### Step 4: Enable Actions

```bash
# Go to your repo → Actions tab
# Click "I understand my workflows, go ahead and enable them"
```

### Step 5: Test Run

```bash
# Actions → Auto Collab Contributions → Run workflow
# Wait 1-2 minutes
# Check for new branch and PR!
```

---

## 🚀 Advanced Setup (Maximize Rewards)

### Create Multiple Target Repos

For maximum impact, create 3-4 repos focused on different aspects:

```bash
# Option 1: Using GitHub CLI (recommended)
gh repo create web3-portfolio --public --description "Web3 Mini Apps & dApps"
gh repo create web3-contracts --public --description "Smart Contract Collection"
gh repo create web3-tools --public --description "Web3 Development Tools"

# Option 2: Manual (github.com/new for each)
# Create these repos:
# 1. web3-portfolio
# 2. web3-contracts  
# 3. web3-tools
```

### Initialize Additional Repos

```bash
# For each repo, add a README
cd ../
git clone https://github.com/YOUR_USERNAME/web3-portfolio.git
cd web3-portfolio
cat > README.md <<EOF
# Web3 Portfolio

Collection of Web3 mini apps, dApps, and prototypes.

## Projects
- Base Mini Apps
- Farcaster Frames
- NFT Collections
- DeFi Interfaces

Built with: React, TypeScript, Solidity, OnchainKit
EOF
git add . && git commit -m "feat: initialize portfolio" && git push

# Repeat for other repos...
```

---

## ⚙️ Enhanced Workflow Configuration

### Update Schedule for More Activity

Create enhanced workflow file:

```bash
cat > .github/workflows/talent-protocol-boost.yml <<'EOF'
name: Talent Protocol Activity Boost

on:
  schedule:
    # Weekday mornings
    - cron: '30 8 * * 1-5'    # 8:30 AM UTC Mon-Fri
    # Weekday afternoons  
    - cron: '0 14 * * 1-5'    # 2:00 PM UTC Mon-Fri
    # Weekday evenings
    - cron: '30 18 * * 1-5'   # 6:30 PM UTC Mon-Fri
    # Weekend (light activity)
    - cron: '0 11 * * 6,0'    # 11:00 AM UTC Sat-Sun
  workflow_dispatch:

jobs:
  build-activity:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Setup Node
        uses: actions/setup-node@v4
        with:
          node-version: 20

      - name: Install deps
        run: npm ci

      - name: Generate content
        run: |
          # Always run generator
          node generate_and_commit.mjs
          
          # 70% chance for mini app
          if [ $((RANDOM % 10)) -lt 7 ]; then
            node generate_miniapp.mjs
          fi
          
          # Always add human touches
          node human_edit.mjs

      - name: Commit changes
        run: |
          git config user.name "github-actions[bot]"
          git config user.email "github-actions[bot]@users.noreply.github.com"
          
          branch="build-$(date +%Y%m%d-%H%M%S)"
          git checkout -b $branch
          git add .
          
          # Get random commit message
          MSG=$(node -e "import('./randomness.mjs').then(m=>console.log(m.getRandomCommitMessage()))")
          git commit -m "$MSG" || echo "No changes"
          
          git push origin $branch || echo "Push failed"

      - name: Create PR
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
          GITHUB_OWNER: ${{ github.repository_owner }}
          GITHUB_REPO: ${{ github.event.repository.name }}
        run: |
          node -e "import('./randomness.mjs').then(r=>import('./github.mjs').then(m=>m.createPR('${{ steps.bn.outputs.branch }}',r.getRandomPRTitle(), process.env.GITHUB_OWNER)))" || echo "PR creation handled"

      - name: Random issue activity
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
          GITHUB_OWNER: ${{ github.repository_owner }}
          GITHUB_REPO: ${{ github.event.repository.name }}
        run: |
          node -e "import('./github.mjs').then(async m=>{await m.maybeCreateIssue();await m.maybeCloseIssue()})" || echo "Issue activity handled"
EOF
```

---

## 📊 Expected Activity Levels

### Conservative (Default)
```
- 2 runs per day
- ~4-6 contributions per day
- 20-30 contributions per week
- Natural weekday > weekend pattern
```

### Boosted (Talent Protocol Optimized)
```
- 3-4 runs per day (weekdays)
- 1 run per day (weekends)
- ~8-12 contributions per day
- 40-60 contributions per week
- Consistent green squares
```

### Your Contribution Graph Will Look Like:
```
     Jan  Feb  Mar  Apr  May  Jun  Jul  Aug  Sep  Oct  Nov  Dec
Mon  ███  ███  ███  ███  ███  ███  ███  ███  ███  ███  ███  ███
Tue  ███  ███  ███  ███  ███  ███  ███  ███  ███  ███  ███  ███
Wed  ███  ███  ███  ███  ███  ███  ███  ███  ███  ███  ███  ███
Thu  ███  ███  ███  ███  ███  ███  ███  ███  ███  ███  ███  ███
Fri  ███  ███  ███  ███  ███  ███  ███  ███  ███  ███  ███  ███
Sat  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓
Sun  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓  ▓▓▓
```

---

## 🎨 Content Strategy for Talent Protocol

### What Gets Generated

**Daily:**
- 2-4 commits with varied messages
- 1-2 PRs (capped at 2/day for safety)
- 1-2 issues created/closed
- 1 mini app (60% chance)

**Weekly:**
- 3-5 Base mini apps
- 3-5 Farcaster mini apps
- 10-15 PRs
- 5-10 issues
- Multiple smart contracts (in templates)

**Monthly:**
- 60-80 contributions
- 12-20 mini apps
- 40-60 PRs
- 20-40 issues

---

## 🏅 Maximizing Talent Protocol Score

### Beyond Automation

**1. Add Real Projects (Critical!)**
```bash
# Weekly: Add 1-2 real projects
# Ideas:
- Deploy a mini app to production
- Contribute to open source Web3 projects
- Build a small protocol
- Create tutorials/documentation
```

**2. Engage with Community**
```
- Comment on Talent Protocol discussions
- Review other builders' work
- Share your progress
- Help others in Discord/Telegram
```

**3. Showcase Your Work**
```
- Pin your best repos
- Update your Talent Protocol profile
- Share deployed apps
- Write about your learnings
```

**4. Quality Signals**
```
✅ Stars on repos
✅ Forks from others
✅ Real issues from users
✅ Deployed applications
✅ Documentation quality
```

---

## 📈 Week-by-Week Plan

### Week 1: Setup & Baseline
```bash
Day 1-2: Setup automation, test workflow
Day 3-4: Let automation run, observe patterns
Day 5-7: Add 1 real project manually
Goal: 20-30 contributions
```

### Week 2: Ramp Up
```bash
Day 1-3: Increase schedule frequency
Day 4-5: Deploy a mini app
Day 6-7: Add documentation
Goal: 40-50 contributions
```

### Week 3: Diversify
```bash
Day 1-2: Add more repos
Day 3-4: Smart contract work
Day 5-7: Community engagement
Goal: 50-60 contributions
```

### Week 4+: Maintain & Grow
```bash
- Keep automation running
- Add real projects weekly
- Engage with community
- Share your progress
Goal: 60+ contributions/week
```

---

## ⚠️ Important Guidelines

### Do This ✅
- Mix automated and real contributions
- Deploy some projects to show they work
- Keep commit messages meaningful
- Engage with the Talent Protocol community
- Gradually increase activity (don't spike suddenly)
- Add real value to the ecosystem

### Don't Do This ❌
- Only rely on automation (Talent Protocol can detect this)
- Spam repos with meaningless commits
- Ignore the quality of generated code
- Forget to engage with community
- Create sudden spikes in activity
- Violate GitHub's terms of service

---

## 🔍 Monitoring Your Progress

### Check Your Stats

```bash
# GitHub Contribution Graph
https://github.com/YOUR_USERNAME

# Talent Protocol Profile
https://passport.talentprotocol.com/YOUR_USERNAME

# Check Your Builder Score
- Log in to Talent Protocol
- View your weekly rewards
- Track your score over time
```

### Key Metrics to Track

```
✅ Contributions per week
✅ Repository count
✅ PR merge rate
✅ Issue activity
✅ Code quality
✅ Community engagement
✅ Deployed projects
```

---

## 🎯 Optimization Tips

### 1. Timing
```bash
# Best times for commits (looks natural):
- Morning: 8-10 AM
- Afternoon: 2-4 PM  
- Evening: 6-8 PM
# Avoid: Late night commits (looks automated)
```

### 2. Variety
```bash
# Mix these activities:
- 60% Commits
- 20% PRs
- 10% Issues
- 10% Reviews/Comments
```

### 3. Quality Over Quantity
```bash
# Better to have:
- 30 quality contributions
# Than:
- 100 low-quality commits
```

---

## 🚨 Troubleshooting

### Workflow Not Running?
```bash
# Check:
1. Actions are enabled (repo settings)
2. GITHUB_TOKEN is set correctly
3. Token has 'repo' and 'workflow' scopes
4. Workflow file syntax is valid
```

### No Contributions Showing?
```bash
# Check:
1. Commits are on default branch or in PRs
2. Email in commits matches GitHub account
3. Contributions aren't marked as private
4. User is not blocked/flagged
```

### PRs Not Creating?
```bash
# Check:
1. Daily caps not reached (max 2/day)
2. GITHUB_TOKEN has permissions
3. Branch was successfully pushed
4. No existing PR with same name
```

---

## 📞 Support

### Resources
- [Talent Protocol Discord](https://discord.gg/talentprotocol)
- [GitHub Actions Docs](https://docs.github.com/en/actions)
- [Web3 Builder Community](https://github.com/YOUR_USERNAME/web3-builder/discussions)

### Getting Help
1. Check logs in Actions tab
2. Review TESTING.md for debugging
3. Ask in Talent Protocol Discord
4. Open issue in this repo

---

## 🎉 Success Checklist

Before going live, ensure:

- [ ] GitHub token created with correct scopes
- [ ] Main repo pushed to GitHub
- [ ] GITHUB_TOKEN secret configured
- [ ] Actions enabled in repo settings
- [ ] Workflow tested manually (Run workflow)
- [ ] First PR created successfully
- [ ] Contribution graph showing activity
- [ ] Talent Protocol profile updated
- [ ] Additional repos created (optional)
- [ ] Community engagement planned

---

## 🚀 Ready to Launch?

```bash
# Final checklist:
npm run test:full          # Test locally
git push origin main       # Push to GitHub
# → Configure secrets
# → Enable Actions  
# → Run workflow
# → Check contribution graph
# → Update Talent Protocol profile
# → Start earning rewards! 🎉
```

---

**Remember:** Automation helps with consistency, but real projects and community engagement are what truly maximize your Talent Protocol rewards. Use this as a foundation, not the entire strategy! 🌟

Good luck, builder! 🏗️
