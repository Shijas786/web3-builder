# Mini Apps - Official SDK Integration

## Overview

The system now generates production-ready mini apps using official SDKs from Base and Farcaster, following their latest documentation and best practices.

## Base Mini Apps

### SDK: `@coinbase/onchainkit`

Based on [Base Mini Apps Documentation](https://docs.base.org/mini-apps/technical-reference/minikit/hooks/useMiniKit)

### Generated Structure
```
miniapps/base-{name}-{timestamp}/
├── package.json          # OnchainKit + React + Vite
├── vite.config.ts        # Vite configuration
├── index.html            # Entry HTML with preconnect
├── main.tsx              # React root with MiniKitProvider
├── App.tsx               # Main app with useMiniKit hook
├── Contract.sol          # Solidity smart contract
└── README.md             # Setup & deployment guide
```

### Key Features

#### 1. **MiniKitProvider Wrapper**
```typescript
<MiniKitProvider>
  <App />
</MiniKitProvider>
```

#### 2. **useMiniKit Hook**
```typescript
const { context, isFrameReady, setFrameReady } = useMiniKit();

useEffect(() => {
  if (!isFrameReady) {
    setFrameReady(); // Hide splash screen
  }
}, [setFrameReady, isFrameReady]);
```

#### 3. **Context Access**
- `context.user.fid` - Farcaster ID
- `context.location` - Launch location (cast, launcher, notification)
- `context.client.added` - App saved status
- `context.client.clientFid` - Host client ("309857" = Base App)

#### 4. **Performance Optimization**
```html
<link rel="preconnect" href="https://auth.farcaster.xyz">
```

### Security Note
⚠️ Context data can be spoofed - use for analytics/UX only, not authentication.

---

## Farcaster Mini Apps

### SDK: `@farcaster/miniapp-sdk`

Based on [Farcaster Mini Apps Documentation](https://miniapps.farcaster.xyz/)

### Generated Structure
```
miniapps/farcaster-{name}-{timestamp}/
├── package.json          # @farcaster/miniapp-sdk + React + Vite
├── vite.config.ts        # Vite configuration
├── index.html            # Entry HTML
├── main.tsx              # React root
├── App.tsx               # Main app with SDK integration
└── README.md             # Setup, auth flow, deployment
```

### Key Features

#### 1. **SDK Initialization**
```typescript
import { sdk } from '@farcaster/miniapp-sdk';

useEffect(() => {
  sdk.actions.ready(); // Signal ready, hide splash
  const ctx = sdk.context;
}, []);
```

#### 2. **Quick Auth (SIWF)**
```typescript
const token = await sdk.quickAuth.getToken();
// Send to backend with Authorization: Bearer <token>
```

Quick Auth is built on Sign In with Farcaster (SIWF) and provides:
- Edge-deployed service for global performance
- Asymmetric JWT signatures for local verification
- No nonce management complexity

#### 3. **Backend Validation**
```typescript
import { createClient } from '@farcaster/quick-auth';

const client = createClient();
const payload = await client.verifyJwt({ 
  token, 
  domain: 'yourdomain.com' 
});
console.log('User FID:', payload.sub);
```

#### 4. **SDK Actions**
- `sdk.actions.ready()` - Hide splash screen
- `sdk.actions.openUrl(url)` - Open external URLs
- `sdk.actions.close()` - Close mini app
- `sdk.context` - User & client info

#### 5. **Developer Mode**
Enable at: [farcaster.xyz/~/settings/developer-tools](https://farcaster.xyz/~/settings/developer-tools)

---

## Why No OAuth 2.0?

Farcaster's decentralized architecture eliminates the need for OAuth:

### Traditional Web (3 parties)
```
User → Platform (OAuth) → Third-party App
```

### Farcaster (Direct)
```
User (cryptographic signature) → App
```

### Key Differences

| OAuth 2.0 | Farcaster |
|-----------|-----------|
| Sign In with X | Sign In with Farcaster (SIWF) |
| Authorization Flow | Quick Auth |
| Centralized APIs | Snapchain + public indexers |
| Access tokens | No equivalent (data is public) |
| Permission scopes | Filters (everything is public) |
| Write permissions | App Keys (delegated signing) |
| Rate limits | Zero-cost reads |

### Benefits
1. **User-owned keys** - Cryptographic signature proves identity
2. **Open data** - Casts, reactions, profiles are public on Snapchain
3. **No rate limits** - Sync yourself or use public indexers
4. **Permissionless** - Build without approval

---

## Generated App Capabilities

### Base Mini Apps
✅ User context (FID, location, saved status)  
✅ Frame readiness handling  
✅ Smart contract integration ready  
✅ OnchainKit components available  
✅ React + TypeScript + Vite  

### Farcaster Mini Apps
✅ Quick Auth authentication  
✅ User FID & username access  
✅ Client detection (Warpcast vs other)  
✅ Profile viewing  
✅ External URL opening  
✅ React + TypeScript + Vite  

---

## Development Workflow

### Local Testing
```bash
cd miniapps/{app-name}
npm install
npm run dev
```

### Production Build
```bash
npm run build
# Deploy dist/ to Vercel/Netlify
```

### Base Mini Apps
1. Deploy contract to Base network
2. Deploy frontend
3. Test in Base App

### Farcaster Mini Apps
1. Enable Developer Mode
2. Deploy frontend
3. Create manifest at developer tools
4. Test in Warpcast/other clients

---

## Resources

### Base
- [Mini Apps Documentation](https://docs.base.org/mini-apps/)
- [OnchainKit MiniKit](https://docs.base.org/mini-apps/technical-reference/minikit/hooks/useMiniKit)
- [Base Developer Portal](https://base.org)

### Farcaster
- [Mini Apps Documentation](https://miniapps.farcaster.xyz/)
- [Quick Auth Guide](https://miniapps.farcaster.xyz/docs/sdk/quick-auth)
- [SDK Reference](https://miniapps.farcaster.xyz/docs/sdk/actions)
- [Developer Tools](https://farcaster.xyz/~/settings/developer-tools)
- [Farcaster Protocol](https://docs.farcaster.xyz/)

---

## Example Usage

### Generate Mini App
```bash
npm run miniapp
```

Output (45% Base, 45% Farcaster, 10% both):
```
✅ Base dApp created: miniapps/base-handmade-granite-bacon-2025-10-01T10-03-03-888Z
```

### Files Created
- Full React + TypeScript setup
- Official SDK integration
- Production-ready configuration
- Deployment documentation
- Smart contracts (Base apps)

---

## Technical Stack

### Base Mini Apps
- **Framework**: React 18 + TypeScript
- **Build Tool**: Vite 5
- **SDK**: @coinbase/onchainkit (latest)
- **Web3**: viem 2.x
- **Blockchain**: Base (Ethereum L2)

### Farcaster Mini Apps
- **Framework**: React 18 + TypeScript
- **Build Tool**: Vite 5
- **SDK**: @farcaster/miniapp-sdk (latest)
- **Protocol**: Snapchain (Farcaster L3)
- **Auth**: Quick Auth (SIWF-based)

Both follow modern web standards and best practices from official documentation.
